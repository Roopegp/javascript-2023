var element = this.document.getElementById("jsdiv");
var num = 500;
var name = "nimi";
var numname = num.toString() + name;
element.innerHTML = numname;